#include<stdio.h>
#include<stdlib.h>

struct node
{
	int val,h;
	struct node *lc,*rc;
};
typedef struct node node;

node* rotate_left(node* pt) {
	node* tmp = pt->rc;
	pt->rc = tmp->lc;
	tmp->lc = pt;
	int hl = (pt->lc == NULL?0:pt->lc->h);
	int hr = (pt->rc == NULL?0:pt->rc->h);
	pt->h = max(hl,hr)+1;
	hl = (tmp->lc == NULL?0:tmp->lc->h);
	hr = (tmp->rc == NULL?0:tmp->rc->h);
	tmp->h = max(hl,hr)+1;
	return tmp;
}

node* balance(node* pt) {
	int hl,hr;
	hl = (pt->lc == NULL?0:pt->lc->h);
	hr = (pt->rc == NULL?0:pt->rc->h);
	if(hl-hr <= 1 && hl-hr >= -1)
	{
		pt->h = max(hl,hr)+1;
		return pt;
	}
	if(hl > hr) {
		int hll,hlr;
		hll = (pt->lc->lc == NULL?0:pt->lc->lc->h);
		hlr = (pt->lc->rc == NULL?0:pt->lc->rc->h);
		if(hll < hlr) pt->lc = rotate_left(pt->lc);
		pt = rotate_right(pt);
		return pt;
	}
}

node* insert(node* pt, int val) {
	if(pt == NULL) {
		pt=(node*)malloc(sizeof(node));
		pt->val = val; pt->h = 1; pt->lc = pt->rc = NULL;
		return pt;
	}
	if(val <= pt->val) pt->lc = insert(pt->lc,val);
	else pt->rc = insert(pt->rc,val);
	pt = balance(pt);
	return pt;
}

int main()
{

	return 0;

}

















