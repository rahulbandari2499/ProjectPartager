#!/bin/bash
declare -a arr
i=0
rem=$#
while [ $# -gt 0 ]
do
	arr[i]=$1
	((i++))
	shift
done
for(( i=0 ;i<$rem ;i++ ))
do
	for (( j=0 ;j< $rem-$i-1 ;j++ ))  
	do
		rahul=$((j+1))
		if [ ${arr[$j]} -gt  ${arr[$(($rahul))]} ] 
		then
			temp=${arr[$j]}
			rohith=$((j+1))	
			arr[$j]=${arr[$((rohith))]} 
			arr[$((rohith))]=$temp
		fi
	done
done
for ((i=0; i<rem ;i++))
do
	echo -n  "${arr[$i]} "
done 
echo   
