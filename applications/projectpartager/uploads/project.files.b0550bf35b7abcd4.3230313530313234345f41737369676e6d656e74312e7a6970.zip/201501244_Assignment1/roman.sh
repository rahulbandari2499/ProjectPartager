#!/bin/bash
declare -a arr
rem=$1
i=0
while [ $rem -gt 0 ]
do
	if [ $rem -ge 1000 ]
	then
		arr[$i]=M
		((i++))
		rem=$(($rem-1000))
	elif [ $rem -ge 500 ]
	then
		if [ $rem -ge 900 ]
		then
			arr[$i]=CM
			((i++))
			rem=$((rem-900))
		else
			arr[$i]=D
			((i++))
			rem=$(($rem-500))
		fi
	elif [ $rem -ge 100 ]
	then
		if [ $rem -ge 400 ]
		then
			arr[$i]=CD
			((i++))
			rem=$((rem-400))
		else
			arr[$i]=C
			((i++))
			rem=$(($rem-100))
		fi
	elif [ $rem -ge 50 ]
	then
		if [ $rem -ge 90 ]
		then
			arr[$i]=XC
			((i++))
			rem=$((rem-90))
		else
			arr[$i]=L
			((i++))    
			rem=$(($rem-50))
		fi
	elif [ $rem -ge 9 ]
	then
		if [ $rem -ge 40 ]
		then
			arr[$i]=XL
			((i++))
			rem=$((rem-40))
		elif [ $rem -eq 9 ]
		then
			arr[$i]=IX
			((i++))    
			rem=$(($rem-9))
		else
			arr[$i]=X
			((i++))    
			rem=$(($rem-10))
		fi
	elif [ $rem -ge 4 ]
	then
		if [ $rem -ge 5 ]
		then
			arr[$i]=V
			((i++))
			rem=$(($rem-5))
		else

			arr[$i]=IV
			((i++))    
			rem=$(($rem-4))
		fi
	else
		arr[$i]=I
		((i++))
		rem=$(($rem-1))
	fi
done
for((j=0;j<i;j++))
do
	echo -n ${arr[$j]}
done
echo



