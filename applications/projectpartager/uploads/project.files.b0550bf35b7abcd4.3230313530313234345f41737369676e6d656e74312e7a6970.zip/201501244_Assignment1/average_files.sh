#!/bin/bash
average()
{
	#echo $1
	temp=$(ls -l $1| awk 'BEGIN{sum=0; n=-1;}{sum += $5; n++;} END {print sum/n;}')
	avg=$( printf "%.0f" $temp)
}
find_files()
{
	num=$(ls -l $1 | wc -l)
	((num--))
	for((i=1; i<=num; i++))
	do
		var=$(ls -l $1|sed '1d' |awk '{print $5}'|head -n $i | tail -n 1)
		#$var
		if [[ $var -ge $avg ]]
		then
			echo -n "$(ls -l $1|sed '1d'| awk '{print $9}'|head -n $i | tail -n 1) "
		fi
	done

}
main()
{
	average $1
	find_files $1
}
main $1
echo
