#!/bin/bash
rahul=1
ping -c $1 google.com | while read line
do
	echo "$(tput setaf $rahul) $(date) --  $line"
	((rahul++))
done
ech
#a=$(($1 +4))
#sed '$a d'

