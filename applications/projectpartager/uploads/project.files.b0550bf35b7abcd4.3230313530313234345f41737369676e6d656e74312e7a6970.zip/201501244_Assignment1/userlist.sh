#!/bin/bash
awk -F':' '{print "USER #"++s" = " $1}' /etc/passwd
